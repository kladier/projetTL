/****************************************************************************
** Meta object code from reading C++ file 'etatright.h'
**
** Created: Thu 4. Mar 04:07:22 2010
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../etatright.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'etatright.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_etatRight[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x05,
      33,   30,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
      62,   60,   10,   10, 0x0a,
      85,   60,   10,   10, 0x0a,
     110,   10,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_etatRight[] = {
    "etatRight\0\0refreshNeeded(int)\0,,\0"
    "etatChanges(int,bool,bool)\0,\0"
    "addTransition(int,int)\0eraseTransition(int,int)\0"
    "etatChange()\0"
};

const QMetaObject etatRight::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_etatRight,
      qt_meta_data_etatRight, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &etatRight::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *etatRight::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *etatRight::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_etatRight))
        return static_cast<void*>(const_cast< etatRight*>(this));
    return QWidget::qt_metacast(_clname);
}

int etatRight::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: refreshNeeded((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: etatChanges((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 2: addTransition((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 3: eraseTransition((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: etatChange(); break;
        default: ;
        }
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void etatRight::refreshNeeded(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void etatRight::etatChanges(int _t1, bool _t2, bool _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE
